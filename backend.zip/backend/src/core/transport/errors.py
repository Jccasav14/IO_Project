class TransportModelError(ValueError):
    """Raised when the transport model is invalid or incomplete."""
