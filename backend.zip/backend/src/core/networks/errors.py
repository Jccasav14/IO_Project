class NetworkModelError(ValueError):
    """Raised when the provided network model is invalid."""
